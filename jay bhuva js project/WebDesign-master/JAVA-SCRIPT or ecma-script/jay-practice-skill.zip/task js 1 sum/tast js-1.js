// task 1
let a =10;
let b =50;
let c = a+b;
 console.log(c)


{
    let p =-1;
    
      if(p<0) {
               console.log( p+"p is a nagativ");
      }
      else if(p>0){
       console.log(p+" is a positiv ");
    }else{
        console.log(p+"is a zero");
    }
}
// task 2
{   
      let year =2005;
      if( year % 5 == 0) {
       console.log("leap year");
      } else {
       console.log("not leap year");
      }
}
//  task 3
{
let  age = 21
let votaingcard =true;
 if (age<=18) {
    console.log("you are a not aligible for voting card ");
 } else {
        if( votaingcard == true ){
            console.log("are you aligible for voting card");
        }
        else{
            console.log("you are not aligible to voting card");
        }
 }    
}

// task 4....
{
    let score =25;
    if (score>=70) {
       console.log("a grade"); 
    }
    else if( score >=80&&score <=90){
        console.log("b grade");
    }
    else if( score >=60&&score <=70){
        console.log(" c grade");
    }
    else if( score >=50&&score <=55){
        console.log(" d grade");
    }
    else{
        console.log("you are flied");
    }
   
}
//  task 5...
{
    let m = 6;
    let n = 5;
    let o = 3;
     if (m>n&&m>o) {
        console.log(m + " is a greater");
     }
     else if (n>m&&n>o) {
        console.log(n + " is a greater");
     }
     else  {
        console.log(o + " is a greater");
     }
}
//  task 6....
{    
   let a = 20;
let b = 15;
console.log("a + b = ", a + b);
console.log("a - b = ", a - b);
console.log("a * b = ", a * b);
console.log("a / b = ", a / b);
console.log("a % b = ", a % b);
console.log("a ** b = ", a ** b);
console.log("a++ = ", a++);
console.log("a-- = ", a--);
}
// task 7..
{
let x = 5;
console.log("x+=5 is" ,x += 5);
console.log("x-=5 is" ,x -= 5);
console.log("x*=5 is" ,x *= 5);
console.log("x/=5 is" ,x /= 5);
console.log("x%=5 is" ,x %= 5);
console.log("x**=5 is" ,x **= 5);
}
//  task 8...
{
let y = 60;  
let z = 50;
console.log("y==z is" ,y==z);
console.log("y!=z is" ,y!=z);
console.log("y===z is" ,y===z);
console.log("y!==z is" ,y!==z);
console.log("y>z is" ,y>z);
console.log("y<z is" ,y<z);
console.log("y>=z is" ,y>=z);
console.log("y<=z is" ,y<=z);
}
// task9
{
    let a =  10;
    let b = 20;
    let c ="/";
     if (c=="+") {
        console.log(a+b);
     } else if(c=="-"){
        console.log(a-b);
     }else if( c=="*"){
        console.log(a*b);
     }else{
        console.log(a/b);
     }
        
     
}



